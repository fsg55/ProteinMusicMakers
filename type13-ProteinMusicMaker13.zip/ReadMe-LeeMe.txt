ReadMe - Leeme.txt

Each Sound Set is made up of 44 'samples', please download a Sound Set for ProteinMusicMaker13 and put all the 'samples' of the same Set in the provided empty folder, called 'sonidos', in the same directory as the executables. exe or .jar, just as you may see in other versions of ProteinMusicMakers. Thanks.

There are 2 versions of PMM13, V1-No Backgrounds and V2-With Backgrounds. Use the one you like best. The sample sets are the same for both versions. You can mix in the folder 'sonidos' any set.Xa of samples with any Set.Xb to your liking.

Enjoy it.

********************************************************************************

Cada Set de sonidos se compone de 44 "samples", por favor descargue un set de sonidos para ProteinMusicMaker13 y ponga todos los "samples" del mismo Set en la carpeta vacia proporcionada, llamada sonidos, en el mismo directorio que los ejecutables .exe o .jar, tal como puede ver en otras versiones de ProteinMusicMakers.Gracias. 


Hay 2 versiones de PMM13, V1-No tiene fondos y V2-con Fondos. Use el que más le guste. Los sets de samples son los mismos para ambas versiones. Puede mezclar en la carpeta 'sonidos' cualquier set.Xa de samples con cualquier Set.Xb, según sea de su agrado.

Disfrútelo.

(C) Florentino Sánchez-García, 2023.