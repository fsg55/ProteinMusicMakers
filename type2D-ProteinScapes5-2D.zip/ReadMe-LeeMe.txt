ReadMe - Leeme.txt

Each Set of sounds are composed of 96 samples, please, mix all samples of the same Set in only one folder called sonidos in the same folder of the .exe of .jar files, as you can see in other versions of ProteinScapes. Thank's.

Enjoy it.

********************************************************************************

Cada Set de sonidos se compone de 96 "samples", por favor mezcle todos los "samples" del mismo Set en una sola carpeta llamada sonidos, en el mismo directorio que los ejecutables .exe o .jar, tal como puede ver en otras versiones de ProteinScapes. Gracias.

Disfrútelo.

(C) Florentino Sánchez-García, 2021.