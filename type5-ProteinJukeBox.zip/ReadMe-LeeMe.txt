ReadMe - Leeme.txt

             Protein JukeBox, a Protein Musicalization Automaton 

Populate each of the subfolders(set0 to set2) of folder sonidos, provided with a complete set of ProteinMusicMaker5 samples; the ones you like the most. 

Launch the provided .exe or .jar, and type the name of one of the provided .csv files. 

The .csv files are plain texts, with the symbolic names and the sequences of each human protein and can be edited with any text editor. 

The program will compose with the sequence first 30 AminoAcids of each protein, an .mp3 file with the musicalization of said sequence, in COMPOS folder. 
Play it, and enjoy them. 

What you are hearing is the musicalization of your protein based on the AA type.

Be patient, between each .mp3 created there is a 5 second pause to allow it to be written to disk.

All the files provided in the .zip, plus de samples, are necessary for this program to work.

Other projects on music from Proteins and DNAs at: https://github.com/fsg55/

Enjoy it.

********************************************************************************

            Protein JukeBox, un Autómata de Musicalización de Proteínas.

Ponga en cada una de las subcarpetas(Set0 a Set2) de la carpeta "sonidos" proporcionadas, un set completo de samples de ProteinMusicMaker5, de los que más le gusten.

Arranque PoteinMusicBox.exe, o .jar, y escriba el nombre de uno de los archivos .csv proporcionados.

Los archivos .csv son textos planos, con los nombres simbólicos y las secuencias de cada proteina humana y pueden ser editados con cualquier editor de texto.

El programa compondrá con los 30 primeros AminoAcidos de la secuencia de cada proteína un archivo .mp3 con la musicalización de dicha secuencia, en la carpeta COMPOS. 

Escúchelos, y disfrútelos. 

Lo que estará oyendo es una musicalización de su proteína basada en cada tipo de AA. 

Sea paciente, entre cada .mp3 creado hay una pausa de 5 segundos para permitir su escritura en disco. 

Todos los archivos proporcionados en el .zip, mas los samples, son necesarios para que este programa funcione.  

Otros proyectos sobre música a partir de Proteínas y ADNs en: https://github.com/fsg55/.

Disfrútelos. 

