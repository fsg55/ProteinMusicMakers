ReadMe - Leeme.txt

This module uses the Sample-Sets for PMM8 or PMM8B.

Each Sound-Set is made up of 44 samples, please download a Sound-Set for ProteinMusicMaker8 and put all the samples from the Set in the provided empty folder called "sonidos" in the same directory as the .exe or .jar executables, as you can see in other versions of ProteinMusicMakers. Thanks.

Enjoy it.

********************************************************************************
Este módulo utiliza los Sets de "samples" de ProteinMusicMaker8 u 8B.

Cada Set de sonidos se compone de 44 "samples", por favor descargue un set de sonidos para ProteinMusicMaker8 y ponga todos los "samples" del Set en la carpeta vacia proporcionada, llamada sonidos, en el mismo directorio que los ejecutables .exe o .jar, tal como puede ver en otras versiones de ProteinMusicMakers. Gracias.

Disfrútelo.

(C) Florentino Sánchez-García, 2022.