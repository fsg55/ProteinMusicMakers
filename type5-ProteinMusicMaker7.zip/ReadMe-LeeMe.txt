ReadMe - Leeme.txt

This module uses the same Sample-Sets as ProteinMusicMaker5.

Each Sound-Set is made up of 116 samples, please download a Sound-Set for ProteinMusicMaker5 and put all the samples from the Set in the provided empty folder called "sonidos" in the same directory as the .exe or .jar executables, as you can see in other versions of ProteinMusicMakers. Thanks.

Enjoy it.

********************************************************************************
Este módulo utiliza los mismos Sets de samples que ProteinMusicMaker5.

Cada Set de sonidos se compone de 116 "samples", por favor descargue un set de sonidos para ProteinMusicMaker5 y ponga todos los "samples" del Set en la carpeta vacia proporcionada, llamada sonidos, en el mismo directorio que los ejecutables .exe o .jar, tal como puede ver en otras versiones de ProteinMusicMakers. Gracias.

Disfrútelo.

(C) Florentino Sánchez-García, 2022.