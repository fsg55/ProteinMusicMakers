ReadMe - Leeme.txt

Protein Music Maker21-Air.

Place all the samples for a specific "Set" (provided in the "Samples-ProteinMusic" subdirectory) into the "sonidos" folder.

Launch the executable (ProteinMusicMaker21-Air.exe or .jar), or enter a protein's amino acid sequence, and click the "Componer" button.

The program will use the first 120 amino acids of the sequence to generate .wav and .mp3 files representing the musical interpretation of that sequence.

Listen to and enjoy them.

What you are hearing is a musical rendition of your protein based on each type of amino acid.

All files included in this .zip archive, as well as the samples, are required for the program to function.

Find other projects involving music based on proteins and DNA at: https://github.com/fsg55/.

Enjoy.

********************************************************************************

Protein Music Maker21-Air.

Protein Music Maker21-Air.

Ponga en la carpeta "sonidos" todos los samples de un "Set" para este modulo proporcionados en el subdiretorio "Samples-PtoteinMusic".

Arranque el ejecutable PoteinMusicMaker21-Air.exe, o .jar, o introduzca una secuencia de AminoAcidos de una proteina, y pulse el boton "Componer".

El programa compondrá con los 120 primeros AminoAcidos de la secuencia de cada proteína un archivo .wav y .mp3 con la musicalización de dicha secuencia. 

Escúchelos, y disfrútelos. 

Lo que estará oyendo es una musicalización de su proteína basada en cada tipo de AA. 

Todos los archivos proporcionados en este .zip, mas los samples, son necesarios para que este programa funcione.  

Otros proyectos sobre música a partir de Proteínas y ADNs en: https://github.com/fsg55/.

Disfrútelos. 

