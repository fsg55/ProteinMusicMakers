ReadMe - Leeme.txt

Each Sound Set is made up of 120 'samples', please download a Sound Set for ProteinMusicMaker9 and put all the 'samples' of the same Set in the provided empty folder, called 'sonidos', in the same directory as the executables. exe or .jar, just as you may see in other versions of ProteinMusicMakers. Thanks.

Enjoy it.

********************************************************************************

Cada Set de sonidos se compone de 120 "samples", por favor descargue un set de sonidos para ProteinMusicMaker9 y ponga todos los "samples" del mismo Set en la carpeta vacia proporcionada, llamada sonidos, en el mismo directorio que los ejecutables .exe o .jar, tal como puede ver en otras versiones de ProteinMusicMakers. Gracias.

Disfrútelo.

(C) Florentino Sánchez-García, 2023.