ReadMe - Leeme.txt

             Protein MusicBox, a Protein Musicalization Automaton 

Populate each of the subfolders(set0 to set4) of folder sonidos, provided with a complete set of ProteinMusicMaker6 samples; the ones you like the most. 

Launch the provided .exe or .jar, and type the name of one of the provided .csv files. 

The .csv files are plain texts, with the symbolic names and the sequences of each human protein and can be edited with any text editor. 

The program will compose with the sequence first 25 AminoAcids of each protein, an .mp3 file with the musicalization of said sequence. Play it, and enjoy them. 

What you are hearing is the musicalization of your protein based on the AA type.

Be patient, between each .mp3 created there is a 8 second pause to allow it to be written to disk.

All the files provided in the .zip, plus de samples, are necessary for this program to work.

Other projects on music from Proteins and DNAs at: https://github.com/fsg55/

Enjoy it.

********************************************************************************

            Protein MusicBox, un Autómata de Musicalización de Proteínas.

Ponga en cada una de las subcarpetas(Set0 a Set4) de la carpeta "sonidos" proporcionadas, un set completo de samples de ProteinMusicMaker6, de los que más le gusten.

Arranque PoteinMusicBox.exe, o .jar, y escriba el nombre de uno de los archivos .csv proporcionados.

Los archivos .csv son textos planos, con los nombres simbólicos y las secuencias de cada proteina humana y pueden ser editados con cualquier editor de texto.

El programa compondrá con los 25 primeros AminoAcidos de la secuencia de cada proteína un archivo .mp3 con la musicalización de dicha secuencia. 

Escúchelos, y disfrútelos. 

Lo que estará oyendo es una musicalización de su proteína basada en cada tipo de AA. 

Sea paciente, entre cada .mp3 creado hay una pausa de 10 segundos para permitir su escritura en disco. 

Todos los archivos proporcionados en el .zip, mas los samples, son necesarios para que este programa funcione.  

Otros proyectos sobre música a partir de Proteínas y ADNs en: https://github.com/fsg55/.

Disfrútelos. 

