Leeme:
Por favor, descargue y mezcle los "samples" A y B de cada Set en la carpeta sonidos, antes de ejecutar el programa ProteinScapes9, para que pueda funcionar.

Gracias y que disfrute con los archivos .wav o .mp creados.

Readme:
Please download and mix samples A and B of each Set in the "sonidos" folder, before running the ProteinScapes9 program, so that it can work.

Thank you and enjoy the .wav or .mp files you create.

