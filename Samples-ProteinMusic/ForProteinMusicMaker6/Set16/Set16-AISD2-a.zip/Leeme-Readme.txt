Leeme-Readme.txt

Leeme:
Los tracks originales de este set de samples han sido realizados por la Inteligencia Artificial de música Soundraw.
https://soundraw.io/

Readme:
The original tracks in this sample set have been made by Soundraw Music Artificial Intelligence.
https://soundraw.io/

