Leeme-Readme.txt

Leeme:
Los tracks originales de este set de samples han sido realizados por la Inteligencia Artificial de música Soundful-beta.
https://my.soundful.com/signin

Readme:
The original tracks in this sample set have been made by Soundful-beta Music Artificial Intelligence.
https://my.soundful.com/signin

